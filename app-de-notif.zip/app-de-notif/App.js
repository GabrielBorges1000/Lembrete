import React, { useEffect, useState } from "react";
import { View, StyleSheet, Alert, TextInput } from "react-native";
import { Text, Button } from "react-native-paper";
import * as Notifications from "expo-notifications";

// CONFIGURAÇÃO BÁSICA DE NOTIFICAÇÕES
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true, 
    shouldPlaySound: true,
  }),
});

const NotificacaoScreen: React.FC = () => {
  const [value, onChangeText] = useState("");

  useEffect(() => {
    configurarPermissoes();
  }, []);

  const configurarPermissoes = async (): Promise<void> => {
    try {
      const { status } = await Notifications.requestPermissionsAsync();
      if (status !== "granted") {
        Alert.alert("Erro", "Permissão para notificações é necessária!");
      }
    } catch (error) {
      Alert.alert("Erro", "Não foi possível configurar as notificações.");
    }
  };

  const enviarNotificacao = async (): Promise<void> => {
    if (!value.trim()) {
      Alert.alert("Atenção", "Digite um lembrete antes de enviar!");
      return;
    }

    try {
      await Notifications.scheduleNotificationAsync({
        content: {
          title: "Lembrete!",
          body: value, // pega o que o usuário digitou
        },
        trigger: {
          seconds: 10, // notifica em 5 segundos
        },
      });
      Alert.alert("Sucesso", "Seu lembrete foi agendado!");
    } catch (error) {
      Alert.alert("Erro", "Não foi possível enviar a notificação.");
    }
  };

  return (
    <View style={styles.container}>
      <Text variant="headlineLarge" style={styles.titulo}>
        Meu Lembrete
      </Text>

      <TextInput
        editable
        placeholder="Digite seu lembrete aqui"
        maxLength={60}
        onChangeText={text => onChangeText(text)}
        value={value}
        style={styles.textInput}
      />

      <Button 
        mode="contained" 
        onPress={enviarNotificacao}
        style={styles.botao}
      >
        Criar Lembrete
      </Button>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f0f4f3",
    paddingHorizontal: 32,
    justifyContent: "center",
    alignItems: "center",
  },
  titulo: {
    color: "#333",
    marginBottom: 24,
    textAlign: "center",
  },
  botao: {
    backgroundColor: "#00bfff",
    marginTop: 16,
    paddingHorizontal: 20,
  },
  textInput: {
    padding: 10,
    borderColor: "#000",
    borderWidth: 1,
    borderRadius: 8,
    width: "100%",
  },
});

export default NotificacaoScreen;
