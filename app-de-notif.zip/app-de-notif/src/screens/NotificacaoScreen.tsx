import React, { useEffect } from "react";
import { View, StyleSheet, Alert } from "react-native";
import { Text, Button } from "react-native-paper";
import * as Notifications from "expo-notifications";

// CONFIGURAÇÃO BÁSICA DE NOTIFICAÇÕES
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true, 
    shouldPlaySound: true,
  }),
});

const NotificacaoScreen: React.FC = () => {
  useEffect(() => {
    configurarPermissoes();
  }, []);

  const configurarPermissoes = async (): Promise<void> => {
    try {
      const { status } = await Notifications.requestPermissionsAsync();
      if (status !== "granted") {
        Alert.alert("Erro", "Permissão para notificações é necessária!");
      }
    } catch (error) {
      Alert.alert("Erro", "Não foi possível configurar as notificações.");
    }
  };

  const enviarNotificacao = async (): Promise<void> => {
    try {
      await Notifications.scheduleNotificationAsync({
        content: {
          title: "Olá!",
          body: "Esta é sua primeira notificação!",
        },
        trigger: null, // Envia imediatamente
      });
      Alert.alert("Sucesso", "Notificação enviada!");
    } catch (error) {
      Alert.alert("Erro", "Não foi possível enviar a notificação.");
    }
  };

  return (
    <View style={styles.container}>
      <Text variant="headlineLarge" style={styles.titulo}>
        Meu App de Notificações
      </Text>

      
      <Text variant="bodyLarge" style={styles.descricao}>
        Aperte o botão para enviar uma notificação!
      </Text>

      <Button 
        mode="contained" 
        onPress={enviarNotificacao}
        style={styles.botao}
      >
        Enviar Notificação
      </Button>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
    paddingHorizontal: 32,
    justifyContent: "center",
    alignItems: "center",
  },
  titulo: {
    color: "#333",
    marginBottom: 24,
    textAlign: "center",
  },
  descricao: {
    color: "#666",
    marginBottom: 48,
    textAlign: "center",
  },
  botao: {
    marginTop: 16,
  },
});

export default NotificacaoScreen;